package application;

public class Swordsmen extends playerChar {

	public Swordsmen() {
		setName("Swordsmen");
		setHP(100);
		setSpeed(0);
		setElement(0);
		setDMG(0);
		setKills(0);
	}
	
}
