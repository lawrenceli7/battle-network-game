package application;

public class Martial_Artist extends playerChar {
	
	public Martial_Artist() {
		setName("Martial Artist");
		setHP(110);
		setSpeed(0);
		setElement(2);
		setDMG(0);
		setKills(0);
	}

}
