package application;

public class Gunner extends playerChar {
	
	public Gunner() {
		setName("Gunner");
		setHP(140);
		setSpeed(0);
		setElement(4);
		setDMG(0);
		setKills(0);
	}

}
