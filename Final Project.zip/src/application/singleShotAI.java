package application;

public class singleShotAI {
	
	final int HP_1 = 50; //HP values for each level of the SinglEShot enemy
	final int HP_2 = 80;
	final int HP_3 = 130;
	final int HP_MAX = 150;
	
	final int ATK_1 = 15; //Attack values for each level of the SingleShot Enemy
	final int ATK_2 = 30;
	final int ATK_3 = 45;
	final int ATK_MAX = 60;
	
	public boolean snglSht1_Behavior() {
		
		return true;
	}
	
}
