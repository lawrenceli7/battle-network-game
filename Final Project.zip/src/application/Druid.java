package application;

public class Druid extends playerChar {
	
	public Druid () {
		setName("Druid");
		setHP(150);
		setSpeed(0);
		setElement(3);
		setDMG(0);
		setKills(0);
	}

}
