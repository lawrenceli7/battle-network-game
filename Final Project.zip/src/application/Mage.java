package application;

public class Mage extends playerChar {
	
	public Mage() {
		setName("Mage");
		setHP(120);
		setSpeed(0);
		setElement(1);
		setDMG(0);
		setKills(0);
	}

}
