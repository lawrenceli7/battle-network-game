package application;

public abstract class Grid {
	protected GridBlock[][] blocks;
	
	
	
}