package application;

public class Enemy extends playerChar {
	
	public Enemy() {
		setName("Enemy");
		setHP(0);
		setSpeed(0);
		setElement(0);
		setDMG(0);
		setKills(0);
	}

}
